import csv
import random
import time

# 模拟持续向左移动的LSM6DSL传感器数据
def generate_left_movement_data(num_samples=100):
    data = []
    for _ in range(num_samples):
        # 模拟加速度计的X轴数据变化，持续向左移动
        accel_x = random.randint(-2000, -1000)  # 模拟左移产生的负加速度，使用随机整数
        accel_y = random.randint(-100, 100)  # 模拟微小的Y轴变化，使用随机整数
        accel_z = random.randint(-100, 100)  # 模拟微小的Z轴变化，使用随机整数
        
        data.append([accel_x, accel_y, accel_z])
        
        time.sleep(0.01)  # 模拟传感器数据的采样间隔
    return data

# 保存数据到CSV文件
def save_data_to_csv(filename, data):
    # header = ["accel_x", "accel_y", "accel_z"]
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        # writer.writerow(header)
        writer.writerows(data)

# 主程序
if __name__ == "__main__":
    num_samples = 1000
    filename = "Left_01_26Hz_4g_mg.csv"
    data = generate_left_movement_data(num_samples)
    
    save_data_to_csv(filename, data)
    print(f"Data saved to {filename}")
